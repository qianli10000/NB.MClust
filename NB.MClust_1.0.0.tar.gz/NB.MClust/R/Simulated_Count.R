#' Data set for illustration: Simulated_Count
#' @format A simulated data frame with 50 rows (i.e. samples) and 100 columns (i.e. variables ).
#'         It can be viewed as simulated RNA-Seq integer counts of 100 genes for 50 patients. 

"Simulated_Count"